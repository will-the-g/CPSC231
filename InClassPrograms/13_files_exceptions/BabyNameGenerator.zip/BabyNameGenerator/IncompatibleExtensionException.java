public class IncompatibleExtensionException extends RuntimeException{
    public IncompatibleExtensionException(String message){
        super(message);
    }
}